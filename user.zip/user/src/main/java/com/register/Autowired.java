package com.register;

public @interface Autowired {

}
