package com.register;

import org.springframework.stereotype.Service;

@Service
public interface UserService {
  @Autowired
 public User findUserByEmail(String email);
 @Autowired
 public void saveUser(User user);
@Autowired
User findUserByUsername(String username);
@Autowired
User findUserByUser(String username);
}